package farm.liveline.BossScore.fragments.live_matches_fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.ScoreCardAdapter;
import farm.liveline.BossScore.beans.PointTableItem;
import farm.liveline.BossScore.beans.ScoreCardItem;
import farm.liveline.BossScore.helper.RequestHandler;
import farm.liveline.BossScore.helper.Utility;

public class ScoreBoardFragment extends Fragment {
    private ListView mScoreCardList;
    private ProgressBar progressBar;
    private ScoreCardAdapter mAdapter;
    private List<ScoreCardItem> scoreItems=new ArrayList<>();
    final static String url="https://cricket-live-line-edbbf.firebaseio.com/.json";
    private String key;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_score_board, container, false);
        mScoreCardList=view.findViewById(R.id.expanded_list_score_board);
        progressBar=view.findViewById(R.id.loading_scoreboard);
        key = getArguments().getString("key");

        mAdapter=new ScoreCardAdapter(getActivity(),scoreItems);
        mScoreCardList.setAdapter(mAdapter);
        try{
            scoreItems.clear();
       //     mFetchListFromAPI();
            fetchMatchInfo();
        }catch (Exception e){
            mScoreCardList.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            Toast.makeText(getContext(), "Data not found yet", Toast.LENGTH_SHORT).show();
        }


        return view;
    }
    private void mFetchListFromAPI() {

        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        mScoreCardList.setVisibility(View.VISIBLE);
                        try {
                            JSONObject jsonobject = new JSONObject(response);


                                if (key.equals("live")){
                                    JSONObject data=jsonobject.getJSONObject("scoreboard");
                                    JSONObject liveMatchs=jsonobject.getJSONObject("LiveLine");
                                    JSONObject liveinfo=liveMatchs.getJSONObject("data");
                                    JSONObject datas=liveinfo.getJSONObject("current_score");
                                    JSONObject datasTeam=datas.getJSONObject("team_bet");

                                    if (data.has("team_1")){
                                        ScoreCardItem scoreData=new ScoreCardItem();
                                        JSONObject bowlerData = data.getJSONObject("team_1");
                                        JSONObject betsData=bowlerData.getJSONObject("batting");
                                        Iterator iteratorBowlerData = betsData .keys();
                                        List<PointTableItem> batsmanList=new ArrayList<>();

                                        scoreData.setTeam_name(Utility.checkString(datasTeam.getString("scoreboardteam1name")));
                                        if (datasTeam.getString("target").equals("0")){
                                            scoreData.setTotal(datasTeam.getString("current_r") + "/" + datasTeam.getString("current_w"));;
                                        }else{
                                            scoreData.setTotal(datasTeam.getString("target") + "/" + datasTeam.getString("team2_current_w"));;
                                        }
                                        scoreData.setExtra("-");
                                        scoreData.setYet_bat("-");

                                        while (iteratorBowlerData.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData.next();

                                            JSONObject bowler=betsData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("run"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("balls")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("4s")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("6s")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("sr")));                                        batsmanList.add(bowlerArray);
                                        }
                                        scoreData.setBatsManList(batsmanList);


                                        //-----------GET BATS MAN LIST---------------
                                        JSONObject bowlData=bowlerData.getJSONObject("bowling");

                                        Iterator iteratorBowlerData1 = bowlData .keys();
                                        List<PointTableItem> bowlerList=new ArrayList<>();
                                        while (iteratorBowlerData1.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData1.next();
                                            JSONObject bowler=bowlData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("overs"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("m")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("runs")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("wicket")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("eco")));
                                            bowlerList.add(bowlerArray);
                                        }
                                        scoreData.setBowlerList(bowlerList);
                                        scoreItems.add(scoreData);
                                    }
                                    //------------GET BOWLER DATA-----------------------
                                    if (data.has("team_2")){
                                        ScoreCardItem scoreData=new ScoreCardItem();
                                        JSONObject bowlerData = data.getJSONObject("team_2");
                                        JSONObject betsData=bowlerData.getJSONObject("batting");
                                        Iterator iteratorBowlerData = betsData .keys();

                                        scoreData.setTeam_name(Utility.checkString(datasTeam.getString("scoreboardteam2name")));
                                        if (datasTeam.getString("target").equals("0")){
                                            scoreData.setTotal(datasTeam.getString("current_r") + "/" + datasTeam.getString("current_w"));;
                                        }else{
                                            scoreData.setTotal(datasTeam.getString("target") + "/" + datasTeam.getString("team2_current_w"));;
                                        }
                                        scoreData.setExtra("-");
                                        scoreData.setYet_bat("-");
                                        List<PointTableItem> batsmanList=new ArrayList<>();

                                        while (iteratorBowlerData.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData.next();

                                            JSONObject bowler=betsData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("run"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("balls")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("4s")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("6s")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("sr")));                                        batsmanList.add(bowlerArray);
                                        }
                                        scoreData.setBatsManList(batsmanList);


                                        //-----------GET BATS MAN LIST---------------
                                        JSONObject bowlData=bowlerData.getJSONObject("bowling");

                                        Iterator iteratorBowlerData1 = bowlData .keys();
                                        List<PointTableItem> bowlerList=new ArrayList<>();
                                        while (iteratorBowlerData1.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData1.next();
                                            JSONObject bowler=bowlData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("overs"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("m")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("runs")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("wicket")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("eco")));
                                            bowlerList.add(bowlerArray);
                                        }
                                        scoreData.setBowlerList(bowlerList);
                                        scoreItems.add(scoreData);
                                    }
                                }
                                else{
                                    JSONObject data=jsonobject.getJSONObject("teamDetail");
                                    JSONObject data1=jsonobject.getJSONObject("RecentMatches").getJSONObject("data").getJSONObject(key);

                                    //------------GET BOWLER DATA-----------------------
                                    if (data.getJSONObject(key).has("team_1")){
                                        ScoreCardItem scoreData=new ScoreCardItem();

                                        JSONObject bowlerData = data.getJSONObject(key).getJSONObject("team_1");

                                        JSONObject matchData=data1.getJSONObject("team_1");
                                        scoreData.setTeam_name(matchData.getString("team_name"));
                                        scoreData.setTotal(matchData.getString("team1_run") + "/" + matchData.getString("team1_wicket"));
                                        scoreData.setExtra("-");
                                        scoreData.setYet_bat("-");
                                        JSONObject betsData=bowlerData.getJSONObject("batting");
                                        Iterator iteratorBowlerData = betsData .keys();
                                        List<PointTableItem> batsmanList=new ArrayList<>();

                                        while (iteratorBowlerData.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData.next();

                                            JSONObject bowler=betsData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("run"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("balls")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("4s")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("6s")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("sr")));                                        batsmanList.add(bowlerArray);
                                        }
                                        scoreData.setBatsManList(batsmanList);


                                        //-----------GET BATS MAN LIST---------------
                                        JSONObject bowlData=bowlerData.getJSONObject("bowling");

                                        Iterator iteratorBowlerData1 = bowlData .keys();
                                        List<PointTableItem> bowlerList=new ArrayList<>();
                                        while (iteratorBowlerData1.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData1.next();
                                            JSONObject bowler=bowlData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("overs"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("m")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("runs")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("wicket")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("eco")));
                                            bowlerList.add(bowlerArray);
                                        }
                                        scoreData.setBowlerList(bowlerList);
                                        scoreItems.add(scoreData);
                                    }
                                    //------------GET BOWLER DATA-----------------------
                                    if (data.getJSONObject(key).has("team_2")){
                                        ScoreCardItem scoreData=new ScoreCardItem();

                                        JSONObject bowlerData = data.getJSONObject(key).getJSONObject("team_2");

                                        JSONObject betsData=bowlerData.getJSONObject("batting");
                                        JSONObject matchData=data1.getJSONObject("team_2");
                                        scoreData.setTeam_name(matchData.getString("team_name"));
                                        scoreData.setTotal(matchData.getString("team2_run") + "/" + matchData.getString("team2_wicket"));
                                        scoreData.setExtra("-");
                                        scoreData.setYet_bat("-");

                                        Iterator iteratorBowlerData = betsData .keys();
                                        List<PointTableItem> batsmanList=new ArrayList<>();

                                        while (iteratorBowlerData.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData.next();

                                            JSONObject bowler=betsData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("run"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("balls")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("4s")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("6s")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("sr")));                                        batsmanList.add(bowlerArray);
                                        }
                                        scoreData.setBatsManList(batsmanList);


                                        //-----------GET BATS MAN LIST---------------
                                        JSONObject bowlData=bowlerData.getJSONObject("bowling");

                                        Iterator iteratorBowlerData1 = bowlData .keys();
                                        List<PointTableItem> bowlerList=new ArrayList<>();
                                        while (iteratorBowlerData1.hasNext()){
                                            String getBowlerno=(String)iteratorBowlerData1.next();
                                            JSONObject bowler=bowlData.getJSONObject(getBowlerno);
                                            PointTableItem bowlerArray=new PointTableItem();
                                            bowlerArray.setTeam_name(Utility.checkString(bowler.getString("name")));
                                            bowlerArray.setW(bowler.getString("overs"));
                                            bowlerArray.setL(String.valueOf(bowler.getInt("m")));
                                            bowlerArray.setD(String.valueOf(bowler.getInt("runs")));
                                            bowlerArray.setM(String.valueOf(bowler.getInt("wicket")));
                                            bowlerArray.setP(String.valueOf(bowler.getInt("eco")));
                                            bowlerList.add(bowlerArray);
                                        }
                                        scoreData.setBowlerList(bowlerList);
                                        scoreItems.add(scoreData);
                                    }

                                }


                            mAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("Scoreboard",e.getMessage());
                            mScoreCardList.setVisibility(View.GONE);
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getContext(), "Data not found yet", Toast.LENGTH_SHORT).show();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        scoreItems.clear();
                        mFetchListFromAPI();
                    }
                }
        );

        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);
    }

    private void fetchMatchInfo(){

        String url = Utility.MATCH_DETAIL_API + key + "/?access_token=" + Utility.getAccessToken(getContext());
        StringRequest stringDRequest = new StringRequest(
                com.android.volley.Request.Method.GET,
                url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            progressBar.setVisibility(View.GONE);
                            mScoreCardList.setVisibility(View.VISIBLE);
                            JSONObject jsonobject = new JSONObject(response);

                            JSONObject objDetails = jsonobject.getJSONObject("data");
                            JSONObject obj = objDetails.getJSONObject("card");

                            JSONObject team = obj.getJSONObject("teams");
                            JSONObject team_1_json = team.getJSONObject("a");
                            JSONObject team_2_json = team.getJSONObject("b");
                            String series_n = obj.getString("title");
                            String location = obj.getString("venue");

                            String match_details = obj.getString("description");
                            String title = obj.getString("name");
                            String matchTyepe = obj.getString("format");
                            String date_time = obj.getJSONObject("start_date").getString("iso");
                            String match_s=obj.getString("status");
                            String team1_nam = team_1_json.getString("name");
                            String team2_nam = team_2_json.getString("name");

                            String flag1 = Utility.BANNER_IMAGE_URI + team_1_json.getString("key") + ".png";
                            String flag2 = Utility.BANNER_IMAGE_URI + team_2_json.getString("key") + ".png";

                            JSONObject details = obj.getJSONObject("innings");

                            String wicket, team1_runs, team1_overs;
                            String wicket2, team2_runs, team2_overs;

                            if (obj.getString("status").equals("completed")) {
                                if (details.has("a_1")) {
                                    JSONObject teamOneDetails = details.getJSONObject("a_1");
                                    wicket = teamOneDetails.getString("wickets");
                                    team1_runs = teamOneDetails.getString("runs");
                                    team1_overs = teamOneDetails.getString("overs");

                                } else {
                                    wicket = "-";
                                    team1_runs = "-";
                                    team1_overs = "-";

                                }

                                if (details.has("b_1")) {
                                    JSONObject teamTwoDetails = details.getJSONObject("b_1");
                                    wicket2 = teamTwoDetails.getString("wickets");
                                    team2_runs = teamTwoDetails.getString("runs");
                                    team2_overs = teamTwoDetails.getString("overs");
                                } else {
                                    wicket2 = "-";
                                    team2_runs = "-";
                                    team2_overs = "-";

                                }
                            } else {
                                wicket = "-";
                                team1_runs = "-";
                                team1_overs = "-";
                                wicket2 = "-";
                                team2_runs = "-";
                                team2_overs = "-";
                            }
                            JSONObject teamPlayersInfo=obj.getJSONObject("players");
                            ScoreCardItem scoreData=new ScoreCardItem();
                            ScoreCardItem scoreData2=new ScoreCardItem();
                            scoreData.setTeam_name(team1_nam+"");
                            scoreData.setExtra("-");
                            scoreData.setYet_bat("-");
                            scoreData.setTotal(team1_runs+"/"+wicket);

                            scoreData2.setTeam_name(team2_nam+"");
                            scoreData2.setExtra("-");
                            scoreData2.setTotal(team2_runs+"/"+wicket2);
                            scoreData2.setYet_bat("-");

                            JSONArray jsonArrayT1=team_1_json.getJSONObject("match").getJSONArray("playing_xi");
                            List<PointTableItem> batsmanList=new ArrayList<>();
                            List<PointTableItem> bowlerList=new ArrayList<>();

                            for (int i = 0; i < jsonArrayT1.length(); i++) {
                                String objs = jsonArrayT1.getString(i);

                                String name=teamPlayersInfo.getJSONObject(objs).getString("fullname");

                                JSONObject batsManDetails=teamPlayersInfo.getJSONObject(objs).getJSONObject("match").getJSONObject("innings").getJSONObject("1").getJSONObject("batting");
                                PointTableItem batsmanArray1=new PointTableItem();

                                if (batsManDetails.has("runs")){
                                    String run=batsManDetails.getString("runs");
                                    String s4=batsManDetails.getString("fours");
                                    String s6=batsManDetails.getString("sixes");
                                    String sr=batsManDetails.getString("strike_rate");
                                    String balls=batsManDetails.getString("balls");
                                    batsmanArray1.setTeam_name(name);
                                    batsmanArray1.setW(run);
                                    batsmanArray1.setL(balls);
                                    batsmanArray1.setD(s4);
                                    batsmanArray1.setM(s6);
                                    batsmanArray1.setP(sr);
                                    batsmanList.add(batsmanArray1);
                                }
                                JSONObject bowlerDetails=teamPlayersInfo.getJSONObject(objs).getJSONObject("match").getJSONObject("innings").getJSONObject("1").getJSONObject("bowling");
                                PointTableItem bowlerArray1=new PointTableItem();
                                if (bowlerDetails.has("overs")){
                                    String over=bowlerDetails.getString("overs");
                                    String run=bowlerDetails.getString("runs");
                                    String wic=bowlerDetails.getString("wickets");
                                    String eco=bowlerDetails.getString("economy");
                                    String m=bowlerDetails.getString("maiden_overs");
                                    bowlerArray1.setTeam_name(name);
                                    bowlerArray1.setW(run);
                                    bowlerArray1.setL(over);
                                    bowlerArray1.setM(m);
                                    bowlerArray1.setP(eco);
                                    bowlerArray1.setD(wic);
                                    bowlerList.add(bowlerArray1);
                                }


                            }
                            scoreData.setBatsManList(batsmanList);
                            scoreData.setBowlerList(bowlerList);
                            scoreItems.add(scoreData);

                            JSONArray jsonArrayT2=team_2_json.getJSONObject("match").getJSONArray("playing_xi");

                            List<PointTableItem> batsmanList2=new ArrayList<>();
                            List<PointTableItem> bowlerList2=new ArrayList<>();


                            for (int i = 0; i < jsonArrayT2.length(); i++) {

                                String objs = jsonArrayT2.getString(i);
                                PointTableItem batsmanArray2=new PointTableItem();

                                String name=teamPlayersInfo.getJSONObject(objs).getString("fullname");
                                JSONObject batsManDetails=teamPlayersInfo.optJSONObject(objs).optJSONObject("match").optJSONObject("innings").optJSONObject("1").optJSONObject("batting");
                                if (batsManDetails.has("runs")){
                                    String run=batsManDetails.getString("runs");
                                    String s4=batsManDetails.getString("fours");
                                    String s6=batsManDetails.getString("sixes");
                                    String sr=batsManDetails.getString("strike_rate");
                                    String balls=batsManDetails.getString("balls");
                                    batsmanArray2.setTeam_name(name);
                                    batsmanArray2.setW(run);
                                    batsmanArray2.setL(balls);
                                    batsmanArray2.setD(s4);
                                    batsmanArray2.setM(s6);
                                    batsmanArray2.setP(sr);
                                    batsmanList2.add(batsmanArray2);
                                }

                                JSONObject bowlerDetails=teamPlayersInfo.optJSONObject(objs).optJSONObject("match").optJSONObject("innings").optJSONObject("1").optJSONObject("bowling");
                                PointTableItem bowlerArray2=new PointTableItem();

                                if (bowlerDetails.has("overs")){
                                    String over=bowlerDetails.getString("overs");
                                    String run=bowlerDetails.getString("runs");
                                    String wic=bowlerDetails.getString("wickets");
                                    String eco=bowlerDetails.getString("economy");
                                    String m=bowlerDetails.getString("maiden_overs");
                                    bowlerArray2.setTeam_name(name);
                                    bowlerArray2.setW(run);
                                    bowlerArray2.setL(over);
                                    bowlerArray2.setM(m);
                                    bowlerArray2.setP(eco);
                                    bowlerArray2.setD(wic);
                                    bowlerList2.add(bowlerArray2);
                                }

                            }
                            scoreData2.setBowlerList(bowlerList2);
                            scoreData2.setBatsManList(batsmanList2);
                            scoreItems.add(scoreData2);
                            mAdapter.notifyDataSetChanged();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);
    }

}
