package farm.liveline.BossScore.fragments.upcoming_match_fragments;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.helper.RequestHandler;
import farm.liveline.BossScore.helper.Utility;

public class UpcomingMatchInfo extends Fragment {

    private TextView matchName, matchType, matchDate, seriesNamel;
    String key;
    ProgressBar progressBar;
    RelativeLayout cardView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming_match_info, container, false);

        matchName = view.findViewById(R.id.match_info_match);
        matchType = view.findViewById(R.id.match_info_match_type);
        matchDate = view.findViewById(R.id.match_info_date);
        progressBar = view.findViewById(R.id.info_pro);
        cardView = view.findViewById(R.id.info_card);
        seriesNamel = view.findViewById(R.id.match_info_series_name);

        key = getArguments().getString("key");

        fetchMatchInfo();

        return view;
    }

    private void fetchMatchInfo() {
        String url = Utility.MATCH_DETAIL_API + key + "/?access_token=" + Utility.getAccessToken(getContext());
        Log.d("URL_MAIN", url);
        StringRequest stringDRequest = new StringRequest(
                com.android.volley.Request.Method.GET,
                url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject jsonobject = new JSONObject(response);

                            JSONObject objDetails = jsonobject.getJSONObject("data");
                            JSONObject obj = objDetails.getJSONObject("card");

                            JSONObject team = obj.getJSONObject("teams");
                            Log.d("DEBUG_HOME", team.getJSONObject("a").getString("name"));
                            JSONObject team_1_json = team.getJSONObject("a");
                            JSONObject team_2_json = team.getJSONObject("b");
                            String series_n = obj.getString("title");
                            String location = obj.getString("venue");

                            String match_details = obj.getString("description");
                            String title = obj.getString("name");
                            String matchTyepe = obj.getString("format");
                            String date_time = obj.getJSONObject("start_date").getString("iso");
                            String match_s = obj.getString("status");
                            String team1_name = team_1_json.getString("name");
                            String team2_name = team_2_json.getString("name");
                            Log.d("DEBUG_HOME", team1_name + " V/S " + team2_name);

                            String flag1 = Utility.BANNER_IMAGE_URI + team_1_json.getString("key") + ".png";
                            String flag2 = Utility.BANNER_IMAGE_URI + team_2_json.getString("key") + ".png";

                            JSONObject details = obj.getJSONObject("innings");

                            String wicket, team1_runs, team1_overs;
                            String wicket2, team2_runs, team2_overs;

                            if (obj.getString("status").equals("completed")) {
                                if (details.has("a_1")) {
                                    JSONObject teamOneDetails = details.getJSONObject("a_1");
                                    wicket = teamOneDetails.getString("wickets");
                                    team1_runs = teamOneDetails.getString("runs");
                                    team1_overs = teamOneDetails.getString("overs");

                                } else {
                                    wicket = "-";
                                    team1_runs = "-";
                                    team1_overs = "-";

                                }

                                if (details.has("b_1")) {
                                    JSONObject teamTwoDetails = details.getJSONObject("b_1");
                                    wicket2 = teamTwoDetails.getString("wickets");
                                    team2_runs = teamTwoDetails.getString("runs");
                                    team2_overs = teamTwoDetails.getString("overs");
                                } else {
                                    wicket2 = "-";
                                    team2_runs = "-";
                                    team2_overs = "-";

                                }
                            } else {
                                wicket = "-";
                                team1_runs = "-";
                                team1_overs = "-";
                                wicket2 = "-";
                                team2_runs = "-";
                                team2_overs = "-";
                            }

                            matchName.setText(title);
                            matchType.setText(matchTyepe.toUpperCase());
                            //    match_refree.setText("-");
                            //    match_toss.setText(obj.getJSONObject("toss").getString("str"));
                            //    match_umpire.setText("-");
                            //    match_three_umpire.setText("-");
                            //    m.setText(match_s);
                            seriesNamel.setText(series_n);

                            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

                            Date sourceDate = null;
                            try {
                                sourceDate = inputFormat.parse(date_time);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            SimpleDateFormat targetFormat = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
                            matchDate.setText(targetFormat.format(sourceDate));


                            // matchDate.setText(date_time);
                            seriesNamel.setText(match_details);

                            progressBar.setVisibility(View.GONE);
                            cardView.setVisibility(View.VISIBLE);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Log.d("DEBUG_ERROR", e.getMessage());

                        }

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("DEBUG_ERROR", error.getMessage());
                    }
                }
        );
        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);


    }

}
