package farm.liveline.BossScore.fragments.bottom;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.TabAdapter;
import farm.liveline.BossScore.fragments.shedualTabs.RecentDetails;
import farm.liveline.BossScore.fragments.shedualTabs.UpcomingDetails;

public class Shedule extends Fragment {
    private TabAdapter mAdapter;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    public Shedule() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_shedule, container, false);
        mTabLayout=view.findViewById(R.id.shedual_tab);
        mViewPager=view.findViewById(R.id.viewPager_Shedual);
        mAdapter = new TabAdapter(getFragmentManager());
        Bundle bundle = new Bundle();
        bundle.putString("info", "data");
        mAdapter.addFragment(new RecentDetails(), "RECENT DETAILS",bundle);
        mAdapter.addFragment(new UpcomingDetails(), "UPCOMING DETAILS",bundle);
        mViewPager.setAdapter(mAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        return view;
    }
}