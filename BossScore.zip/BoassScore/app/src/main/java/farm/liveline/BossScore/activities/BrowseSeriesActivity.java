package farm.liveline.BossScore.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import farm.liveline.BossScore.R;

public class BrowseSeriesActivity extends AppCompatActivity {

    ImageView match_info_toolbar_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_series);
        match_info_toolbar_back= findViewById(R.id.match_info_toolbar_back);
        match_info_toolbar_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}