package farm.liveline.BossScore.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.tabs.TabLayout;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.TabAdapter;
import farm.liveline.BossScore.fragments.matches_fragments.MatchesFragment;
import farm.liveline.BossScore.fragments.matches_fragments.PointTableFragment;

public class MatchInfo extends AppCompatActivity {
    private TabAdapter mAdapter;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match_info);
        mTabLayout=findViewById(R.id.match_info_tab);
        mViewPager=findViewById(R.id.viewPager_match_info);
        mAdapter = new TabAdapter(getSupportFragmentManager());
        ImageView mFinish=findViewById(R.id.match_info_toolbar_left);
        Bundle bundle = new Bundle();
        bundle.putString("info", "data");
        mAdapter.addFragment(new MatchesFragment(), "MATCH INFO",bundle);
        mAdapter.addFragment(new PointTableFragment(), "POINT TABLE",bundle);
        mViewPager.setAdapter(mAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
