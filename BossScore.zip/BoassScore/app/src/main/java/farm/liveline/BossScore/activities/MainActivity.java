package farm.liveline.BossScore.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.shashank.sony.fancytoastlib.FancyToast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.ViewPagerAdapterBottom;
import farm.liveline.BossScore.helper.RequestHandler;
import farm.liveline.BossScore.fragments.bottom.Home;
import farm.liveline.BossScore.fragments.bottom.News;
import farm.liveline.BossScore.fragments.bottom.Setting;
import farm.liveline.BossScore.fragments.bottom.Shedule;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    private ViewPager viewPager;
    Home homeFragment;
    Shedule shedualeFragment;
    News newsFragment;
    Setting settingFragment;
    MenuItem prevMenuItem;
    private ImageView mImageView;
    String whatsAppurl, imageUrl;
    final static String url="https://api.storelyapp.com:5000/v1/getGames/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.viewpagerBottom);
        mImageView = findViewById(R.id.banner);
        viewPager.setOffscreenPageLimit(4);
        mFetchListFromAPI();
        //Initializing the bottomNavigationView
        bottomNavigationView = findViewById(R.id.navigation_bottom_bar);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_home:
                                viewPager.setCurrentItem(0);
                                break;
                            case R.id.action_sheduale:
                                viewPager.setCurrentItem(1);
                                break;
                            case R.id.action_news:
                                viewPager.setCurrentItem(2);
                                break;
                            case R.id.action_setting:
                                viewPager.setCurrentItem(3);
                                break;
                        }
                        return true;
                    }
                });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (prevMenuItem != null) {
                    prevMenuItem.setChecked(false);
                } else {
                    bottomNavigationView.getMenu().getItem(0).setChecked(false);
                }
                Log.d("page", "onPageSelected: " + position);
                bottomNavigationView.getMenu().getItem(position).setChecked(true);
                prevMenuItem = bottomNavigationView.getMenu().getItem(position);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        setupViewPager(viewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        mFetchListFromAPI();
        ViewPagerAdapterBottom adapter = new ViewPagerAdapterBottom(getSupportFragmentManager());
        homeFragment = new Home();
        shedualeFragment = new Shedule();
        newsFragment = new News();
        settingFragment = new Setting();
        adapter.addFragment(homeFragment);
        adapter.addFragment(shedualeFragment);
        adapter.addFragment(newsFragment);
        adapter.addFragment(settingFragment);
        viewPager.setAdapter(adapter);
    }

    private void mFetchListFromAPI() {

        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonobjectMain = new JSONObject(response);
                            final JSONArray jsonObject = jsonobjectMain.getJSONArray("data");
                            Log.d("dataApi", jsonObject.toString());
                            getData(jsonObject);
                            Glide.with(getApplicationContext())
                                    .load("https://api.storelyapp.com:5000/" + imageUrl)
                                    .into(mImageView);
                            final String urlWhatsapp = whatsAppurl;
                            mImageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlWhatsapp));
                                    FancyToast.makeText(MainActivity.this, "WELCOME USER  !!!!", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
                                    startActivity(browserIntent);
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("MainError", e.getMessage());
                            Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_SHORT).show();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        mFetchListFromAPI();
                    }
                }
        );

        RequestHandler.getInstance(this).addToRequestQueue(stringDRequest);

    }

    private void getData(JSONArray jsonArray) {

        if (jsonArray.length() > 0) {
            for (int i = 0; i < jsonArray.length(); i++) {
                final JSONObject obj;

                try {
                    obj = jsonArray.getJSONObject(i);
                    if (obj.getString("name").equals("Nova exchange")) {
                        Log.d("dataApi", obj.toString());
                        imageUrl = obj.getString("banner");
                        whatsAppurl = obj.getString("url");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } else {
            //Toast.makeText(getContext(), "News not found !", Toast.LENGTH_SHORT).show();
        }
    }
}
