package farm.liveline.BossScore.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.tabs.TabLayout;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.TabAdapter;
import farm.liveline.BossScore.fragments.upcoming_match_fragments.UpcomingMatchInfo;
import farm.liveline.BossScore.fragments.upcoming_match_fragments.UpcomingSquadFragment;

public class UpcomingMatchesDeatils extends AppCompatActivity {
    private TabAdapter mAdapter;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private ImageView mFinish;

    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upcoming_matches_deatils);
        mTabLayout = findViewById(R.id.upcoming_info_tab);
        mViewPager = findViewById(R.id.viewPager_upcoming_match_info);
        mFinish = findViewById(R.id.match_info_toolbar_left);

        key = getIntent().getExtras().getString("key");
        int type = getIntent().getExtras().getInt("type");

        mAdapter = new TabAdapter(getSupportFragmentManager());
        Bundle bundle = new Bundle();
        bundle.putString("info", "data");

        bundle.putString("key", key);
        if (type == 1) {
            mAdapter.addFragment(new UpcomingMatchInfo(), "MATCH INFO", bundle);
            mAdapter.addFragment(new UpcomingSquadFragment(), "SQUADS", bundle);
        } else {
            mAdapter.addFragment(new UpcomingMatchInfo(), "MATCH INFO", bundle);
            mAdapter.addFragment(new UpcomingSquadFragment(), "SQUADS", bundle);
        }

        mViewPager.setAdapter(mAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
