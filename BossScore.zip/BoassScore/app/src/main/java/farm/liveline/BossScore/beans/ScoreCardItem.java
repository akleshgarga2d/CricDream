package farm.liveline.BossScore.beans;

import java.util.List;

public class ScoreCardItem {
    String team_name,total,extra,yet_bat;
    List<PointTableItem> batsManList;
    List<PointTableItem> bowlerList;

    public ScoreCardItem() {

    }

    public ScoreCardItem(String team_name, String total, String extra, String yet_bat, List<PointTableItem> batsManList, List<PointTableItem> bowlerList) {
        this.team_name = team_name;
        this.total = total;
        this.extra = extra;
        this.yet_bat = yet_bat;
        this.batsManList = batsManList;
        this.bowlerList = bowlerList;
    }

    public List<PointTableItem> getBatsManList() {
        return batsManList;
    }

    public void setBatsManList(List<PointTableItem> batsManList) {
        this.batsManList = batsManList;
    }

    public List<PointTableItem> getBowlerList() {
        return bowlerList;
    }

    public void setBowlerList(List<PointTableItem> bowlerList) {
        this.bowlerList = bowlerList;
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    public String getYet_bat() {
        return yet_bat;
    }

    public void setYet_bat(String yet_bat) {
        this.yet_bat = yet_bat;
    }

}
