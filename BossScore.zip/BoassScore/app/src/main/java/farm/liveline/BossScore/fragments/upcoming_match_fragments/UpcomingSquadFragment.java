package farm.liveline.BossScore.fragments.upcoming_match_fragments;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

import farm.liveline.BossScore.R;

public class UpcomingSquadFragment extends Fragment {
    private ChipGroup chipGroupOne;
    private ChipGroup chipGroupTwo;
    private List<String> tagsGroupOne = new ArrayList<>(), tagsGroupTwo = new ArrayList<>();
    private TextView tvTeam1, tvTeam2, matchType, matchDate, seriesNamel;
    String key;
    ProgressBar progressBar;
    CardView cardView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming_squad, container, false);

        tvTeam1 = view.findViewById(R.id.match_info_match);
        tvTeam2 = view.findViewById(R.id.match_info_match_type);

        key = getArguments().getString("key");

        chipGroupOne = view.findViewById(R.id.chip_group_one);
        chipGroupTwo = view.findViewById(R.id.chip_group_two);
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupOne.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        tagsGroupTwo.add("--");
        setTagOne(tagsGroupOne);
        setTagTwo(tagsGroupTwo);
        return view;
    }

    private void setTagOne(final List<String> tagList) {

        for (int index = 0; index < tagList.size(); index++) {
            final String tagName = tagList.get(index);
            final Chip chip = new Chip(getContext());
            int paddingDp = (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 10,
                    getResources().getDisplayMetrics()
            );
            chip.setPadding(paddingDp, paddingDp, paddingDp, paddingDp);
            chip.setText(tagName);


            chipGroupOne.addView(chip);
        }
    }

    private void setTagTwo(final List<String> tagList) {

        for (int index = 0; index < tagList.size(); index++) {
            final String tagName = tagList.get(index);
            final Chip chip = new Chip(getContext());
            int paddingDp = (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 10,
                    getResources().getDisplayMetrics()
            );
            chip.setPadding(paddingDp, paddingDp, paddingDp, paddingDp);
            chip.setText(tagName);

            chipGroupTwo.addView(chip);
        }
    }
}
