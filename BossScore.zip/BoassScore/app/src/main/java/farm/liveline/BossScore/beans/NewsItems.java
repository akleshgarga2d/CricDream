package farm.liveline.BossScore.beans;

public class NewsItems {
    String news_title;
    public NewsItems() {

    }
    public NewsItems(String news_title, String news_description, String news_image) {
        this.news_title = news_title;
        this.news_description = news_description;
        this.news_image = news_image;
    }

    String news_description;

    public String getNews_title() {
        return news_title;
    }

    public void setNews_title(String news_title) {
        this.news_title = news_title;
    }

    public String getNews_description() {
        return news_description;
    }

    public void setNews_description(String news_description) {
        this.news_description = news_description;
    }

    public String getNews_image() {
        return news_image;
    }

    public void setNews_image(String news_image) {
        this.news_image = news_image;
    }

    String news_image;

}
