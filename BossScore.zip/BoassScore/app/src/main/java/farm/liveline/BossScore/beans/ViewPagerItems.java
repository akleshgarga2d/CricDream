package farm.liveline.BossScore.beans;

import org.json.JSONObject;

public class ViewPagerItems {
    int type;
    String key;
    String venue;

    public ViewPagerItems(int type, String venue, String key, String match_name, JSONObject jsonObject, String date, String team_one_name, String team_two_name, String team_one_score, String team_two_score, String team1_overs, String team2_overs, String flag_one, String flag_two, String wicket1, String wicket2, String status) {
        this.type = type;
        this.venue = venue;
        this.key = key;
        this.match_name = match_name;
        this.jsonObject = jsonObject;
        this.date = date;
        this.team1_overs = team1_overs;
        this.team2_overs = team2_overs;
        this.team_one_name = team_one_name;
        this.team_two_name = team_two_name;
        this.team_one_score = team_one_score;
        this.team_two_score = team_two_score;
        this.flag_one = flag_one;
        this.flag_two = flag_two;
        this.wicket1 = wicket1;
        this.wicket2 = wicket2;
        this.status = status;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public JSONObject getJsonObject() {
        return jsonObject;
    }


    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }


    String match_name;
    JSONObject jsonObject;

    public ViewPagerItems() {
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    String date;
    String team_one_name;
    String team_two_name;
    String team_one_score;
    String team_two_score;
    String flag_one;
    String flag_two;
    String team1_overs;
    String team2_overs;
    String wicket1;
    String wicket2;
    String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWicket1() {
        return wicket1;
    }

    public void setWicket1(String wicket1) {
        this.wicket1 = wicket1;
    }

    public String getWicket2() {
        return wicket2;
    }

    public void setWicket2(String wicket2) {
        this.wicket2 = wicket2;
    }

    public String getMatch_name() {
        return match_name;
    }

    public String getTeam1_overs() {
        return team1_overs;
    }

    public void setTeam1_overs(String team1_overs) {
        this.team1_overs = team1_overs;
    }

    public String getTeam2_overs() {
        return team2_overs;
    }

    public void setTeam2_overs(String team2_overs) {
        this.team2_overs = team2_overs;
    }

    public void setMatch_name(String match_name) {
        this.match_name = match_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTeam_one_name() {
        return team_one_name;
    }

    public void setTeam_one_name(String team_one_name) {
        this.team_one_name = team_one_name;
    }

    public String getTeam_two_name() {
        return team_two_name;
    }

    public void setTeam_two_name(String team_two_name) {
        this.team_two_name = team_two_name;
    }

    public String getTeam_one_score() {
        return team_one_score;
    }

    public void setTeam_one_score(String team_one_score) {
        this.team_one_score = team_one_score;
    }

    public String getTeam_two_score() {
        return team_two_score;
    }

    public void setTeam_two_score(String team_two_score) {
        this.team_two_score = team_two_score;
    }

    public String getFlag_one() {
        return flag_one;
    }

    public void setFlag_one(String flag_one) {
        this.flag_one = flag_one;
    }

    public String getFlag_two() {
        return flag_two;
    }

    public void setFlag_two(String flag_two) {
        this.flag_two = flag_two;
    }
}