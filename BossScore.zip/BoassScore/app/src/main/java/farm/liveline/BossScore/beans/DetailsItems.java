package farm.liveline.BossScore.beans;

public class DetailsItems {
    String flag_one;
    String flag_two;
    String team_one;
    String key;
    String time;


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getFlag_one() {
        return flag_one;
    }

    public void setFlag_one(String flag_one) {
        this.flag_one = flag_one;
    }

    public String getFlag_two() {
        return flag_two;
    }

    public void setFlag_two(String flag_two) {
        this.flag_two = flag_two;
    }

    public String getTeam_one() {
        return team_one;
    }

    public void setTeam_one(String team_one) {
        this.team_one = team_one;
    }

    public String getTeam_two() {
        return team_two;
    }

    public void setTeam_two(String team_two) {
        this.team_two = team_two;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getTour_info() {
        return tour_info;
    }

    public void setTour_info(String tour_info) {
        this.tour_info = tour_info;
    }

    public String getMore_info() {
        return more_info;
    }

    public void setMore_info(String more_info) {
        this.more_info = more_info;
    }

    public DetailsItems(){}
    public DetailsItems(String flag_one, String flag_two, String team_one, String team_two, String venue, String tour_info, String more_info,String key,String time) {
        this.flag_one = flag_one;
        this.flag_two = flag_two;
        this.team_one = team_one;
        this.team_two = team_two;
        this.venue = venue;
        this.tour_info = tour_info;
        this.more_info = more_info;
        this.key=key;
        this.time=time;
    }

    String team_two;
    String venue;
    String tour_info;
    String more_info;
}
