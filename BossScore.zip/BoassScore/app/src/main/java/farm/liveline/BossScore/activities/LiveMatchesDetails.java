package farm.liveline.BossScore.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.tabs.TabLayout;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.Utils.Utillity;
import farm.liveline.BossScore.adapter.TabAdapter;
import farm.liveline.BossScore.fragments.live_matches_fragments.InfoFragment;
import farm.liveline.BossScore.fragments.live_matches_fragments.LiveNewFragments;
import farm.liveline.BossScore.fragments.live_matches_fragments.ScoreBoardFragment;

public class LiveMatchesDetails extends AppCompatActivity {

    private static String TAGC = LiveMatchesDetails.class.getName();

    private TabAdapter mAdapter;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    String key;
    private ImageView mFinish;

    public String status, match_key = "", team1_name, team2_name, team1_logo, team2_logo, score = "", score2 = "", wicket1 = "", wicket2 = "", team1_oversstr = "", team2_oversstr = "";
    //------------GOOGLE ADS------------------
    private AdView mAdView;
    ImageView finish;
    ImageView ivBell;
    private String frag_name = "top_frag";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_matches_details);


        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        mTabLayout = findViewById(R.id.live_matches_tab);
        mFinish = findViewById(R.id.shedual_toolbar_left);
        mViewPager = findViewById(R.id.viewPager_live_info);
        mAdapter = new TabAdapter(getSupportFragmentManager());
        //     intentData=getIntent().getExtras().getString("data");
        key = getIntent().getExtras().getString("key");
        int type = getIntent().getExtras().getInt("type");
        if (getIntent() != null) {
            match_key = getIntent().getExtras().getString("key");
            team1_name = getIntent().getExtras().getString("team1_name");
            team2_name = getIntent().getExtras().getString("team2_name");
            team1_logo = getIntent().getExtras().getString("team1_logo");
            team2_logo = getIntent().getExtras().getString("team2_logo");
            score = getIntent().getExtras().getString("score");
            score2 = getIntent().getExtras().getString("score2");
            wicket1 = getIntent().getExtras().getString("wicket1");
            wicket2 = getIntent().getExtras().getString("wicket2");
            team1_oversstr = getIntent().getExtras().getString("team1_overs");
            team2_oversstr = getIntent().getExtras().getString("team2_overs");
            status = getIntent().getExtras().getString("status");
            Utillity.p(TAGC + " ", " match_key " + match_key);
            type = getIntent().getExtras().getInt("type");
            //System.out.println("matchkeyyyyyyyy********"+match_key);

            try {
                if (getIntent().getExtras().getString("frag_name") != null) {
                    frag_name = getIntent().getExtras().getString("frag_name");
                } else {
                    frag_name = "top_frag";
                }
            } catch (Exception e) {
                frag_name = "top_frag";
                e.printStackTrace();
            }
        }


        Bundle bundle = new Bundle();
        bundle.putString("team1_name", team1_name);
        bundle.putString("team2_name", team2_name);
        bundle.putString("team1_logo", team1_logo);
        bundle.putString("team2_logo", team2_logo);
        bundle.putString("score", score);
        bundle.putString("score2", score2);
        bundle.putString("team1_overs", team1_oversstr);
        bundle.putString("team2_overs", team2_oversstr);
        bundle.putString("wicket1", wicket1);
        bundle.putString("wicket2", wicket2);
        bundle.putString("status", status);
        Utillity.p(TAGC + " ", " match_key " + match_key);
        type = getIntent().getExtras().getInt("type");
        //    bundle.putString("info", intentData);

        bundle.putString("key", key);
        if (type == 1) {
            mAdapter.addFragment(new InfoFragment(), "INFO", bundle);
            mAdapter.addFragment(new LiveNewFragments(), "LIVE", bundle);
            mAdapter.addFragment(new ScoreBoardFragment(), "SCOREBOARD", bundle);
        } else {
            mAdapter.addFragment(new InfoFragment(), "INFO", bundle);
            mAdapter.addFragment(new ScoreBoardFragment(), "SCOREBOARD", bundle);
        }
        mViewPager.setAdapter(mAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
