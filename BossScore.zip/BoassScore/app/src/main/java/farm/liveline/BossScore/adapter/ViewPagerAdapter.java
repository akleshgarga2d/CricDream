package farm.liveline.BossScore.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.shashank.sony.fancytoastlib.FancyToast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import farm.liveline.BossScore.R;
import farm.liveline.BossScore.beans.ViewPagerItems;
import farm.liveline.BossScore.activities.LiveMatchesDetails;

public class ViewPagerAdapter extends PagerAdapter {
    Activity activity;
    List<ViewPagerItems> itemsList;


    public ViewPagerAdapter(Activity activity, List<ViewPagerItems> itemsList) {
        this.activity = activity;
        this.itemsList = itemsList;
    }

    LayoutInflater inflater;

    @Override
    public int getCount() {
        return itemsList.size();
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }


    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        inflater = (LayoutInflater) activity.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View itemView = inflater.inflate(R.layout.home_view_pager_card_design, container, false);
        RelativeLayout cardView = (RelativeLayout) itemView.findViewById(R.id.cardView);
        TextView match_name = (TextView) itemView.findViewById(R.id.match_name);
        TextView team_one = (TextView) itemView.findViewById(R.id.team_one_name);
        TextView team_two = (TextView) itemView.findViewById(R.id.team_two_name);
        TextView score_one = (TextView) itemView.findViewById(R.id.team_one_score);
        TextView score_two = (TextView) itemView.findViewById(R.id.team_two_score);
        TextView v_s = (TextView) itemView.findViewById(R.id.v_s_text);
        final ImageView isLiveImage = (ImageView) itemView.findViewById(R.id.is_live_icon);
        isLiveImage.setVisibility(View.GONE);
        CircleImageView flag_one = (CircleImageView) itemView.findViewById(R.id.flag_one);
        CircleImageView flag_two = (CircleImageView) itemView.findViewById(R.id.flag_two);
        final TextView date = (TextView) itemView.findViewById(R.id.date_text);
        final ViewPagerItems viewPagerItems = itemsList.get(position);
        if (viewPagerItems.getType() == 1) {
            isLiveImage.setVisibility(View.VISIBLE);
            cardView.setBackground(activity.getResources().getDrawable(R.drawable.card));
            match_name.setTextColor(Color.parseColor("#FFFFFF"));
            team_one.setTextColor(Color.parseColor("#FFFFFF"));
            team_two.setTextColor(Color.parseColor("#FFFFFF"));
            score_one.setTextColor(Color.parseColor("#FFFFFF"));
            score_two.setTextColor(Color.parseColor("#FFFFFF"));
            date.setTextColor(Color.parseColor("#FFDE03"));


        } else {
            cardView.setBackground(activity.getResources().getDrawable(R.drawable.rectangle_border));
            match_name.setTextColor(Color.parseColor("#FFFFFF"));
            team_one.setTextColor(Color.parseColor("#FFFFFF"));
            team_two.setTextColor(Color.parseColor("#FFFFFF"));
            score_one.setTextColor(Color.parseColor("#FFFFFF"));
            score_two.setTextColor(Color.parseColor("#FFFFFF"));

            date.setTextColor(Color.parseColor("#FFFFFF"));
            isLiveImage.setVisibility(View.GONE);

        }
        match_name.setText(viewPagerItems.getMatch_name());
        team_one.setText(viewPagerItems.getTeam_one_name());
        team_two.setText(viewPagerItems.getTeam_two_name());
        score_one.setText(viewPagerItems.getTeam_one_score());
        score_two.setText(viewPagerItems.getTeam_two_score());
        if (viewPagerItems.getType() == 2) {

            try {

                SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

                Date da = null;
                Date now = new Date();
                String dates = input.format(now);
                //     d = input.parse(datasTeam.getString("match_date_time"));

                da = input.parse(dates);
                Date di = input.parse(viewPagerItems.getDate());
                long mills = di.getTime() - da.getTime();
                new CountDownTimer(mills, 1000) {
                    @Override
                    public void onTick(long mill) {
                        isLiveImage.setVisibility(View.GONE);
                        int hours = (int) (mill / (1000 * 60 * 60));
                        int mins = (int) (mill / (1000 * 60)) % 60;
                        int sec = (int) (mill / (1000) % 60);

                        String diff = hours + ":" + mins + ":" + sec;
                        Log.d("Time", diff);
                        date.setTextColor(Color.parseColor("#FFDE03"));
                        date.setText("MATCH STARTS IN " + diff);
                    }

                    @Override
                    public void onFinish() {
                        isLiveImage.setVisibility(View.GONE);
                        date.setText("Live soon");
                    }
                }.start();
            } catch (Exception e) {

                e.printStackTrace();
                Log.d("PARSE_ERROR", e.getMessage());
            }

        } else {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
            Date futureDate = null;
            try {
                futureDate = inputFormat.parse(viewPagerItems.getDate() + "");
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String formattedDate = outputFormat.format(futureDate);

            date.setText(formattedDate);
        }


        try {
            if (!viewPagerItems.getFlag_one().equals("ER")) {
                Glide.with(activity.getApplicationContext())
                        .load(viewPagerItems.getFlag_one())
                        .placeholder(R.mipmap.icon_ic_appicon)
                        .into(flag_one);
            } else {
                Glide.with(activity.getApplicationContext())
                        .load(R.mipmap.icon_ic_appicon)
                        .into(flag_one);
            }

            if (!viewPagerItems.getFlag_two().equals("ER")) {
                Glide.with(activity.getApplicationContext())
                        .load(viewPagerItems.getFlag_two())
                        .placeholder(R.mipmap.icon_ic_appicon)
                        .into(flag_two);
            } else {
                Glide.with(activity.getApplicationContext())
                        .load(R.mipmap.icon_ic_appicon)
                        .into(flag_two);
            }

        } catch (Exception e) {

        }
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (viewPagerItems.getType() != 2) {
                    Intent intent = new Intent(itemView.getContext(), LiveMatchesDetails.class);
                    intent.putExtra("key", viewPagerItems.getKey());
                    intent.putExtra("type", viewPagerItems.getType());
                    intent.putExtra("team1_name", viewPagerItems.getTeam_one_name());
                    intent.putExtra("team2_name", viewPagerItems.getTeam_two_name());
                    intent.putExtra("team1_logo", viewPagerItems.getFlag_one());
                    intent.putExtra("team2_logo", viewPagerItems.getFlag_two());
                    intent.putExtra("score", viewPagerItems.getTeam_one_score());
                    intent.putExtra("score2", viewPagerItems.getTeam_two_score());
                    intent.putExtra("team1_overs", viewPagerItems.getTeam1_overs());
                    intent.putExtra("team2_overs", viewPagerItems.getTeam2_overs());
                    intent.putExtra("wicket1", viewPagerItems.getWicket1());
                    intent.putExtra("wicket2", viewPagerItems.getWicket2());
                    intent.putExtra("status", viewPagerItems.getStatus());
                    activity.startActivity(intent);
                } else {
                    FancyToast.makeText(activity, "Oops MATCH STARTING VERY SOON !!!!", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
                }
            }
        });
        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        ((ViewPager) container).removeView((View) object);
    }
}