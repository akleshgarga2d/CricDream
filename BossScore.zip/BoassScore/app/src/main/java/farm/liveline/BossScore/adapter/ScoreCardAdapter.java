package farm.liveline.BossScore.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.beans.PointTableItem;
import farm.liveline.BossScore.beans.ScoreCardItem;

public class ScoreCardAdapter extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<ScoreCardItem> listItems;

    private PointTableAdapter mAdapterBowler;
    private List<PointTableItem> bowlerTableItems=new ArrayList<>();


    private PointTableAdapter mAdapterBatsman;
    private List<PointTableItem> batsmanTableItems=new ArrayList<>();


    public ScoreCardAdapter(Activity activity, List<ScoreCardItem> listItems) {
        this.activity = activity;
        this.listItems = listItems;
    }

    @Override
    public int getCount() {

        return listItems.size();    }

    @Override
    public Object getItem(int position) {
        return listItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.score_board_layout, null);

        TextView title = (TextView) convertView.findViewById(R.id.score_board_team_name);
        TextView desc = (TextView) convertView.findViewById(R.id.score_board_score);
        TextView extra=(TextView)convertView.findViewById(R.id.score_board_extra);
        TextView yetTobat=(TextView)convertView.findViewById(R.id.score_board_yet_to_bat);
        ListView bowlerList=(ListView)convertView.findViewById(R.id.score_board_bowler_list);
        ListView batsList=(ListView)convertView.findViewById(R.id.score_board_batsman_list);
        // getting movie data for the row
        ScoreCardItem m = listItems.get(position);
        title.setText(m.getTeam_name());
        desc.setText(m.getTotal());
        extra.setText(m.getExtra());
        yetTobat.setText(m.getYet_bat());
        mAdapterBowler=new PointTableAdapter(activity,m.getBowlerList());
        bowlerList.setAdapter(mAdapterBowler);

        mAdapterBatsman=new PointTableAdapter(activity,m.getBatsManList());
        batsList.setAdapter(mAdapterBatsman);
        return convertView;
    }
}
