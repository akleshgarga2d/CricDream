package farm.liveline.BossScore.beans;

public class BannerItems {
    String name;
    String number;
    String URL;
    String banner;
    String id;
    String created_on;
    String app_name;
    boolean is_active;

    public BannerItems(String name, String number, String URL, String banner, String id, String created_on, String app_name, boolean is_active) {
        this.name = name;
        this.number = number;
        this.URL = URL;
        this.banner = banner;
        this.id = id;
        this.created_on = created_on;
        this.app_name = app_name;
        this.is_active = is_active;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreated_on() {
        return created_on;
    }

    public void setCreated_on(String created_on) {
        this.created_on = created_on;
    }

    public String getApp_name() {
        return app_name;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public boolean isIs_active() {
        return is_active;
    }

    public void setIs_active(boolean is_active) {
        this.is_active = is_active;
    }


}

