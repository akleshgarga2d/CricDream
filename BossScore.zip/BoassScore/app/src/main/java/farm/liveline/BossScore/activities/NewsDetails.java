package farm.liveline.BossScore.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import farm.liveline.BossScore.R;

public class NewsDetails extends AppCompatActivity {

    private ImageView imageView;
    private TextView textViewTitle,textViewDescription;
    ImageView mFinish;
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);
        imageView=findViewById(R.id.news_details_image);
        mFinish=findViewById(R.id.match_info_toolbar_left);
        textViewTitle=findViewById(R.id.news_details_title);
        textViewDescription=findViewById(R.id.news_details_description);
        String image=getIntent().getExtras().getString("image");
        String title=getIntent().getExtras().getString("title");
        String description=getIntent().getExtras().getString("description");
        textViewTitle.setText(title);
        textViewDescription.setText(description);
        Glide.with(this)
                .load(image)
                .into(imageView);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
