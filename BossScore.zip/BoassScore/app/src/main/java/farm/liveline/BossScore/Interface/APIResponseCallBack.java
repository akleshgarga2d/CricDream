package farm.liveline.BossScore.Interface;

import org.json.JSONObject;

public interface APIResponseCallBack
{
    public void apiResponseCallBackJson(String apiName, JSONObject jsonObject);
}
