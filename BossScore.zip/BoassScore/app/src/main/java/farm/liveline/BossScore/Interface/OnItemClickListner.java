package farm.liveline.BossScore.Interface;


import farm.liveline.BossScore.beans.TeamDetails;

public interface OnItemClickListner {
    public void onItemClicked(int position, TeamDetails teamDetails);
    public void onItemRefresh(int position, TeamDetails teamDetails);
}
