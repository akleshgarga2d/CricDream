package farm.liveline.BossScore.fragments.bottom;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.NewsAdapter;
import farm.liveline.BossScore.beans.NewsItems;
import farm.liveline.BossScore.helper.RequestHandler;
import farm.liveline.BossScore.activities.NewsDetails;


public class News extends Fragment {
    final static String url = "https://livescore6.p.rapidapi.com/news/list?category=cricket";
    private ProgressBar progressBar;
    private ListView mNewsListView;
    private NewsAdapter mNewsAdapter;
    private List<NewsItems> newsItems = new ArrayList<>();
    private ScrollView scrollView;
    JSONArray jsonArray;
    TextView mFound;

    public News() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_news, container, false);
        mNewsListView = view.findViewById(R.id.main_news_list);
        scrollView = view.findViewById(R.id.news_scrollview);
        progressBar = view.findViewById(R.id.loading_news);
        mNewsAdapter = new NewsAdapter(getActivity(), newsItems);
        mNewsListView.setAdapter(mNewsAdapter);
        mFound = view.findViewById(R.id.news_not_found);
        mFetchListFromAPI();
        mNewsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String image = newsItems.get(i).getNews_image();
                String title = newsItems.get(i).getNews_title();
                String description = newsItems.get(i).getNews_description();

                Intent il = new Intent(getActivity(), NewsDetails.class);
                il.putExtra("image", image);
                il.putExtra("title", title);
                il.putExtra("description", description);
                startActivity(il);
            }
        });
        return view;
    }

    private void mFetchListFromAPI() {

        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        scrollView.setVisibility(View.VISIBLE);
                        progressBar.setVisibility(View.GONE);
                        try {

                            JSONObject jsonobject = new JSONObject(response);
                            jsonArray = jsonobject.getJSONArray("arts");

                            getData(jsonArray);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getContext(), e.getMessage().toString(), Toast.LENGTH_LONG).show();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        mFound.setVisibility(View.VISIBLE);
                        //            Toast.makeText(getContext(), "API NOT WORKING", Toast.LENGTH_SHORT).show();
                        mFetchListFromAPI();
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("content-type", "application/json");
                params.put("x-rapidapi-host", "livescore6.p.rapidapi.com");
                params.put("x-rapidapi-key", "d8dd056a73msh8a5ffee0891991dp1ddae9jsna9f688347177");
                return params;
            }
        };

        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);

    }

    private void getData(JSONArray jsonArray) {

        if (jsonArray.length() > 0) {
            mFound.setVisibility(View.GONE);
            scrollView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
            for (int i = 0; i < jsonArray.length(); i++) {
                final JSONObject obj;
                NewsItems newsItems1 = new NewsItems();

                try {
                    obj = jsonArray.getJSONObject(i);
                    newsItems1.setNews_title(obj.getString("tit"));
                    newsItems1.setNews_description(obj.getString("des"));
                    newsItems1.setNews_image(obj.getString("img"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                newsItems.add(newsItems1);

            }
            mNewsAdapter.notifyDataSetChanged();
        } else {
            mFound.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            //Toast.makeText(getContext(), "News not found !", Toast.LENGTH_SHORT).show();
        }
    }
}
