package farm.liveline.BossScore.fragments.shedualTabs;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.shashank.sony.fancytoastlib.FancyToast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.DetailsAdapter;
import farm.liveline.BossScore.beans.DetailsItems;
import farm.liveline.BossScore.helper.RequestHandler;
import farm.liveline.BossScore.helper.Utility;
import farm.liveline.BossScore.activities.UpcomingMatchesDeatils;

public class UpcomingDetails extends Fragment {
    private ListView mListView;
    private DetailsAdapter mAdapter;
    private List<DetailsItems> mItemList = new ArrayList<>();
    private ProgressBar mProgressBar;
    final static String url = "https://cricket-live-line-edbbf.firebaseio.com/.json";
    TextView mFound;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming_details, container, false);
        mProgressBar = view.findViewById(R.id.loading_upcoming_details);
        mListView = view.findViewById(R.id.upcomming_details_list);
        mFound = view.findViewById(R.id.nodata);
        mFound.setVisibility(View.VISIBLE);
        getMatchesList();
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String key_id = mItemList.get(i).getKey();
                String room_id = mItemList.get(i).getFlag_one();
                Intent il = new Intent(getActivity(), UpcomingMatchesDeatils.class);
                FancyToast.makeText(getActivity(), "MATCH STARTING VERY SOON !!!!", FancyToast.LENGTH_LONG, FancyToast.INFO, false).show();
                il.putExtra("key", key_id);
                il.putExtra("type", 0);
                startActivity(il);
            }
        });
        return view;
    }

    private void getMatchesList() {
        String url = Utility.RECENT_MATCH_API + Utility.getAccessToken(getContext());

        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonobject = new JSONObject(response);

                            JSONObject jsonObject = jsonobject.getJSONObject("data");
                            JSONArray jsonArray = jsonObject.getJSONArray("intelligent_order");
                            int i = 0;
                            final int j = 0;
                            mItemList.clear();
                            while (i < jsonArray.length()) {
                                final String objs = jsonArray.getString(i);
                                String url = Utility.MATCH_DETAIL_API + objs + "/?access_token=" + Utility.getAccessToken(getContext());
                                StringRequest stringDRequest = new StringRequest(
                                        Request.Method.GET,
                                        url,
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {

                                                try {

                                                    JSONObject jsonobject = new JSONObject(response);

                                                    JSONObject objDetails = jsonobject.getJSONObject("data");
                                                    JSONObject obj = objDetails.getJSONObject("card");

                                                    JSONObject team = obj.getJSONObject("teams");
                                                    JSONObject team_1_json = team.getJSONObject("a");
                                                    JSONObject team_2_json = team.getJSONObject("b");

                                                    String match_details = obj.getString("name");
                                                    String title = obj.getString("name");
                                                    String location = obj.getString("venue");
                                                    String date_time = obj.getJSONObject("start_date").getString("iso");

                                                    String team1_name = team_1_json.getString("name");
                                                    String team2_name = team_2_json.getString("name");

                                                    String flag1 = Utility.BANNER_IMAGE_URI + team_1_json.getString("key") + ".png";
                                                    String flag2 = Utility.BANNER_IMAGE_URI + team_2_json.getString("key") + ".png";

                                                    JSONObject details = obj.getJSONObject("innings");

                                                    String wicket, team1_runs, team1_overs;
                                                    String wicket2, team2_runs, team2_overs;
                                                    String status = obj.getString("status");

                                                    if (!status.equals("notstarted")) {
                                                        if (details.has("a_1")) {
                                                            JSONObject teamOneDetails = details.getJSONObject("a_1");
                                                            wicket = teamOneDetails.getString("wickets");
                                                            team1_runs = teamOneDetails.getString("runs");
                                                            team1_overs = teamOneDetails.getString("overs");

                                                        } else {
                                                            wicket = "-";
                                                            team1_runs = "-";
                                                            team1_overs = "-";

                                                        }

                                                        if (details.has("b_1")) {
                                                            JSONObject teamTwoDetails = details.getJSONObject("b_1");
                                                            wicket2 = teamTwoDetails.getString("wickets");
                                                            team2_runs = teamTwoDetails.getString("runs");
                                                            team2_overs = teamTwoDetails.getString("overs");
                                                        } else {
                                                            wicket2 = "-";
                                                            team2_runs = "-";
                                                            team2_overs = "-";

                                                        }
                                                    } else {
                                                        wicket = "-";
                                                        team1_runs = "-";
                                                        team1_overs = "-";
                                                        wicket2 = "-";
                                                        team2_runs = "-";
                                                        team2_overs = "-";
                                                    }

                                                    String key = String.valueOf(objs);
                                                    final DetailsItems liveMatche = new DetailsItems();

                                                    liveMatche.setKey(key);
                                                    liveMatche.setTeam_one(team1_name);
                                                    liveMatche.setTeam_two(team2_name);
                                                    liveMatche.setFlag_one(flag1);
                                                    liveMatche.setFlag_two(flag2);
                                                    liveMatche.setTime(date_time);
                                                    liveMatche.setTour_info(title);
                                                    liveMatche.setVenue(location);
                                                    liveMatche.setMore_info(match_details);
                                                    if (status.equals("notstarted")) {
                                                        mItemList.add(liveMatche);
                                                    }
                                                    mAdapter = new DetailsAdapter(getActivity(), mItemList);
                                                    mListView.setAdapter(mAdapter);


                                                    Log.d("HOME_ERROR_3", "OK");

                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Log.d("HOME_ERROR_3", error.getMessage());
                                            }
                                        }
                                );
                                RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);

                                i++;
                            }

                            mProgressBar.setVisibility(View.GONE);
                            mFound.setVisibility(View.GONE);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Log.d("HOME_ERROR_3", e.getMessage());

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("HOME_ERROR_3", error.getMessage());

                    }
                }
        );

        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);
        mListView.setVisibility(View.VISIBLE);

    }

}
