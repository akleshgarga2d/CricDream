package farm.liveline.BossScore.fragments.bottom;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.NewsAdapter;
import farm.liveline.BossScore.adapter.ViewPagerAdapter;
import farm.liveline.BossScore.beans.NewsItems;
import farm.liveline.BossScore.beans.ViewPagerItems;
import farm.liveline.BossScore.helper.RequestHandler;
import farm.liveline.BossScore.helper.Utility;
import farm.liveline.BossScore.activities.NewsDetails;

public class Home extends Fragment {
    private ViewPager mLiveMatchesList;
    JSONArray jsonArray;
    private ViewPagerAdapter mAdapter;
    private List<ViewPagerItems> viewPagerItemsList = new ArrayList<>();
    final static String url_news = "https://livescore6.p.rapidapi.com/news/list?category=cricket";
    NestedScrollView scrollView;

    final static String url = "https://cricket-live-line-edbbf.firebaseio.com/.json";
    private ProgressBar progressBar;
    //------------NEWS LISTVIEW -----------------
    private ListView mNewsListView;
    private NewsAdapter mNewsAdapter;
    private List<NewsItems> newsItems = new ArrayList<>();
    View view;
    boolean isLoaded = false;

    public Home() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        mLiveMatchesList = view.findViewById(R.id.viewPager);
        scrollView = view.findViewById(R.id.home_scroll);
        mNewsListView = view.findViewById(R.id.news_list);
        progressBar = view.findViewById(R.id.home_loading);
        mNewsAdapter = new NewsAdapter(getActivity(), newsItems);
        mNewsListView.setAdapter(mNewsAdapter);
        mNewsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String image = newsItems.get(i).getNews_image();
                String title = newsItems.get(i).getNews_title();
                String description = newsItems.get(i).getNews_description();
                Intent il = new Intent(getActivity(), NewsDetails.class);
                il.putExtra("image", image);
                il.putExtra("title", title);
                il.putExtra("description", description);
                startActivity(il);
            }
        });
        Utility.GetAuthToken mgetAuthToken = new Utility.GetAuthToken(getActivity());
        mgetAuthToken.run();
        getMatchesList();
        mFetchListNewsFromAPI();

        mLiveMatchesList.setPageTransformer(false, new ViewPager.PageTransformer() {
            @Override
            public void transformPage(View page, float position) {
                int pageWidth = mLiveMatchesList.getMeasuredWidth() - mLiveMatchesList.getPaddingLeft() - mLiveMatchesList.getPaddingRight();
                int pageHeight = mLiveMatchesList.getHeight() + 20;
                int paddingLeft = mLiveMatchesList.getPaddingLeft();
                float transformPos = (float) (page.getLeft() - (mLiveMatchesList.getScrollX() + paddingLeft)) / pageWidth;

                final float normalizedposition = Math.abs(Math.abs(transformPos) - 1);
                page.setAlpha(normalizedposition + 0.5f);

                int max = -pageHeight / 10;

                if (transformPos < -1) { // [-Infinity,-1)
                    // This page is way off-screen to the left.
                    page.setTranslationY(0);
                } else if (transformPos <= 1) { // [-1,1]
                    page.setTranslationY(max * (1 - Math.abs(transformPos)));

                } else { // (1,+Infinity]
                    // This page is way off-screen to the right.
                    page.setTranslationY(0);
                }
            }
        });
        return view;
    }

    private void getMatchesList() {
        String url = Utility.RECENT_MATCH_API + Utility.getAccessToken(getContext());

        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonobject = new JSONObject(response);

                            JSONObject jsonObject = jsonobject.getJSONObject("data");
                            JSONArray jsonArray = jsonObject.getJSONArray("intelligent_order");
                            int i = 0;
                            viewPagerItemsList.clear();
                            while (i < jsonArray.length()) {
                                final String objs = jsonArray.getString(i);
                                String url = Utility.MATCH_DETAIL_API + objs + "/?access_token=" + Utility.getAccessToken(getContext());
                                StringRequest stringDRequest = new StringRequest(
                                        Request.Method.GET,
                                        url,
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {

                                                try {

                                                    JSONObject jsonobject = new JSONObject(response);

                                                    JSONObject objDetails = jsonobject.getJSONObject("data");
                                                    JSONObject obj = objDetails.getJSONObject("card");

                                                    JSONObject team = obj.getJSONObject("teams");
                                                    JSONObject team_1_json = team.getJSONObject("a");
                                                    JSONObject team_2_json = team.getJSONObject("b");

                                                    String match_details = obj.getString("name");
                                                    String title = obj.getString("name");
                                                    String location = obj.getString("venue");
                                                    String date_time = obj.getJSONObject("start_date").getString("iso");

                                                    String team1_name = team_1_json.getString("name");
                                                    String team2_name = team_2_json.getString("name");

                                                    String flag1 = Utility.BANNER_IMAGE_URI + team_1_json.getString("key") + ".png";
                                                    String flag2 = Utility.BANNER_IMAGE_URI + team_2_json.getString("key") + ".png";

                                                    JSONObject details = obj.getJSONObject("innings");

                                                    String wicket, team1_runs, team1_overs;
                                                    String wicket2, team2_runs, team2_overs;
                                                    String status = obj.getString("status");


                                                    if (!status.equals("notstarted")) {
                                                        if (details.has("a_1")) {
                                                            JSONObject teamOneDetails = details.getJSONObject("a_1");
                                                            wicket = teamOneDetails.getString("wickets");
                                                            team1_runs = teamOneDetails.getString("runs");
                                                            team1_overs = teamOneDetails.getString("overs");

                                                        } else {
                                                            wicket = "0";
                                                            team1_runs = "00";
                                                            team1_overs = "00.0";

                                                        }

                                                        if (details.has("b_1")) {
                                                            JSONObject teamTwoDetails = details.getJSONObject("b_1");
                                                            wicket2 = teamTwoDetails.getString("wickets");
                                                            team2_runs = teamTwoDetails.getString("runs");
                                                            team2_overs = teamTwoDetails.getString("overs");
                                                        } else {
                                                            wicket2 = "0";
                                                            team2_runs = "00";
                                                            team2_overs = "00.0";

                                                        }
                                                    } else {
                                                        wicket = "0";
                                                        team1_runs = "00";
                                                        team1_overs = "00.0";
                                                        wicket2 = "0";
                                                        team2_runs = "00";
                                                        team2_overs = "00.0";
                                                    }

                                                    String key = String.valueOf(objs);
                                                    final ViewPagerItems liveMatche = new ViewPagerItems();

                                                    liveMatche.setKey(key);
                                                    liveMatche.setTeam_one_name(team1_name);
                                                    liveMatche.setTeam_two_name(team2_name);
                                                    liveMatche.setFlag_one(flag1);
                                                    liveMatche.setFlag_two(flag2);
                                                    liveMatche.setDate(date_time);
                                                    liveMatche.setMatch_name(title);
                                                    liveMatche.setTeam_one_score(team1_runs + "/" + wicket + "(" + team1_overs + ")");
                                                    liveMatche.setTeam_two_score(team2_runs + "/" + wicket2 + "(" + team2_overs + ")");
                                                    if (status.equals("notstarted"))
                                                        liveMatche.setType(2);
                                                    if (status.equals("started"))
                                                        liveMatche.setType(1);
                                                    if (status.equals("completed"))
                                                        liveMatche.setType(3);
                                                    Log.d("HOME_ERROR", "OK");
                                                    viewPagerItemsList.add(liveMatche);
                                                    mAdapter = new ViewPagerAdapter(getActivity(), viewPagerItemsList);
                                                    mLiveMatchesList.setAdapter(mAdapter);
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Log.d("HOME_ERROR", error.getMessage());
                                            }
                                        }
                                );
                                RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);

                                i++;
                            }
                            Log.d("HOME_ERROR_2", String.valueOf(viewPagerItemsList.size()));

                            progressBar.setVisibility(View.GONE);
                            scrollView.setVisibility(View.VISIBLE);
                              mFetchListNewsFromAPI();


                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);
    }

    private void mFetchListNewsFromAPI() {

        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url_news,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonobject = new JSONObject(response);
                            jsonArray = jsonobject.getJSONArray("arts");

                            getData(jsonArray);

                        } catch (JSONException e) {
                            e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        mNewsListView.setVisibility(View.GONE);
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("content-type", "application/json");
                params.put("x-rapidapi-host", "livescore6.p.rapidapi.com");
                params.put("x-rapidapi-key", "d8dd056a73msh8a5ffee0891991dp1ddae9jsna9f688347177");
                return params;
            }
        };

        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);

    }

    private void getData(JSONArray jsonArray) {
        mNewsListView.setVisibility(View.VISIBLE);
        if (jsonArray.length() > 0) {
            for (int i = 0; i < 6; i++) {
                final JSONObject obj;
                NewsItems newsItems1 = new NewsItems();

                try {
                    obj = jsonArray.getJSONObject(i);
                    newsItems1.setNews_title(obj.getString("tit"));
                    newsItems1.setNews_description(obj.getString("des"));
                    newsItems1.setNews_image(obj.getString("img"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                newsItems.add(newsItems1);
            }
            mNewsAdapter.notifyDataSetChanged();
        } else {
            //    Toast.makeText(getContext(), "News not found !", Toast.LENGTH_SHORT).show();
        }
    }


}
