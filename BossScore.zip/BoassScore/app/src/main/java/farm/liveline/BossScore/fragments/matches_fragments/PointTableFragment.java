package farm.liveline.BossScore.fragments.matches_fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.List;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.PointTableAdapter;
import farm.liveline.BossScore.beans.PointTableItem;

public class PointTableFragment extends Fragment {
    private ProgressBar progressBar;
    private ListView mPointList;
    private PointTableAdapter mAdapter;
    private List<PointTableItem> pointTableItems=new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_point_table, container, false);
        progressBar=view.findViewById(R.id.loading_matches);
        mPointList=view.findViewById(R.id.listview_point_table);
        mAdapter=new PointTableAdapter(getActivity(),pointTableItems);
        mPointList.setAdapter(mAdapter);
        mFetchListFromAPI();

        return view;
    }

    private void mFetchListFromAPI() {
        for (int i=0;i<10;i++){
            PointTableItem listDemo=new PointTableItem();
            listDemo.setTeam_name("Team name");
            listDemo.setW("00");
            listDemo.setD("00");
            listDemo.setL("00");
            listDemo.setP("0.00");
            listDemo.setM("0.00");

            pointTableItems.add(listDemo);
        }
        mAdapter.notifyDataSetChanged();
    }

}
