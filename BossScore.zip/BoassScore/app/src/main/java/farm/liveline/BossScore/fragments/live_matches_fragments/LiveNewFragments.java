package farm.liveline.BossScore.fragments.live_matches_fragments;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import cc.cloudist.acplibrary.ACProgressConstant;
import cc.cloudist.acplibrary.ACProgressFlower;
import de.hdodenhof.circleimageview.CircleImageView;
import farm.liveline.BossScore.R;
import farm.liveline.BossScore.Utils.Constants;
import farm.liveline.BossScore.Utils.RequestHandler;
import farm.liveline.BossScore.Utils.Utillity;
import farm.liveline.BossScore.api.CommonMethod;
import farm.liveline.BossScore.beans.BattingItem;
import farm.liveline.BossScore.beans.BowlerItems;
import farm.liveline.BossScore.beans.RunModel;


public class LiveNewFragments extends Fragment {
    private static String TAGC = LiveNewFragments.class.getName();
    public String match_key;
    private ACProgressFlower acProgressFlower;
    RecyclerView bat_list, ball_list;
    public RelativeLayout live_lay;
    private View view;
    private ArrayList<BattingItem> batlist = new ArrayList<>();
    private TextView last_run, now_overs, ball1_tv, ball2_tv, ball3_tv, ball4_tv, ball5_tv, ball6_tv, tvFavoriteteam, tvMarketrate1, tvMarketrate2, tvSession1, tvSession2, current_partenership_tv, target_tv;
    private FrameLayout ball1_lay, ball2_lay, ball3_lay, ball4_lay, ball5_lay, ball6_lay;
    private ImageView ball1_im, ball2_im, ball3_im, ball4_im, ball5_im, ball6_im;
    private ArrayList<BowlerItems> balllist = new ArrayList<>();
    private ArrayList<RunModel> runModelArrayList = new ArrayList<>();

    public String status, team1_name, team2_name, team1_logo, team2_logo, score = "", score2 = "", wicket1 = "", wicket2 = "", team1_oversstr = "", team2_oversstr = "";

    private String frag_name = "top_frag";

    private CircleImageView imageView_team1, imageView_team2;

    private TextView team1_runs, team2_runs, team1_overs, team2_overs, team1_short_name, team2_short_name, current_run_rate, need_run, remain_balls, run_rate;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_live, container, false);


        match_key = getArguments().getString("key");
        team1_name = getArguments().getString("team1_name");
        team2_name = getArguments().getString("team2_name");
        team1_logo = getArguments().getString("team1_logo");
        team2_logo = getArguments().getString("team2_logo");
        score = getArguments().getString("score");
        score2 = getArguments().getString("score2");
        wicket1 = getArguments().getString("wicket1");
        wicket2 = getArguments().getString("wicket2");
        team1_oversstr = getArguments().getString("team1_overs");
        team2_oversstr = getArguments().getString("team2_overs");
        status = getArguments().getString("status");

        init(view);
        return view;
    }


    public void init(View v) {

        now_overs = (TextView) v.findViewById(R.id.now_overs);
        tvFavoriteteam = (TextView) v.findViewById(R.id.tvFavoriteteam);
        tvMarketrate1 = (TextView) v.findViewById(R.id.tvMarketrate1);
        tvMarketrate2 = (TextView) v.findViewById(R.id.tvMarketrate2);
        tvSession1 = (TextView) v.findViewById(R.id.tvSession1);
        tvSession2 = (TextView) v.findViewById(R.id.tvSession2);
        last_run = (TextView) v.findViewById(R.id.last_run);

        imageView_team1 = v.findViewById(R.id.imageView_team1);
        imageView_team2 = v.findViewById(R.id.imageView_team2);

        live_lay = (RelativeLayout) v.findViewById(R.id.live_lay);
        bat_list = (RecyclerView) v.findViewById(R.id.bat_list);
        ball_list = (RecyclerView) v.findViewById(R.id.ball_list);
        ball1_im = (ImageView) v.findViewById(R.id.ball1_im);
        ball2_im = (ImageView) v.findViewById(R.id.ball2_im);
        ball3_im = (ImageView) v.findViewById(R.id.ball3_im);
        ball4_im = (ImageView) v.findViewById(R.id.ball4_im);
        ball5_im = (ImageView) v.findViewById(R.id.ball5_im);
        ball6_im = (ImageView) v.findViewById(R.id.ball6_im);
        ball1_lay = (FrameLayout) v.findViewById(R.id.ball1);
        ball2_lay = (FrameLayout) v.findViewById(R.id.ball2);
        ball3_lay = (FrameLayout) v.findViewById(R.id.ball3);
        ball4_lay = (FrameLayout) v.findViewById(R.id.ball4);
        ball5_lay = (FrameLayout) v.findViewById(R.id.ball5);
        ball6_lay = (FrameLayout) v.findViewById(R.id.ball6);
        ball1_tv = (TextView) v.findViewById(R.id.ball1_tv);
        ball2_tv = (TextView) v.findViewById(R.id.ball2_tv);
        ball3_tv = (TextView) v.findViewById(R.id.ball3_tv);
        ball4_tv = (TextView) v.findViewById(R.id.ball4_tv);
        ball5_tv = (TextView) v.findViewById(R.id.ball5_tv);
        ball6_tv = (TextView) v.findViewById(R.id.ball6_tv);
        current_partenership_tv = (TextView) v.findViewById(R.id.current_partnership);
        target_tv = (TextView) v.findViewById(R.id.target);


        team1_runs = v.findViewById(R.id.team1_runs);
        team2_runs = v.findViewById(R.id.team2_runs);
        team1_overs = v.findViewById(R.id.team1_overs);
        team2_overs = v.findViewById(R.id.team2_overs);
        imageView_team1 = v.findViewById(R.id.imageView_team1);
        imageView_team2 = v.findViewById(R.id.imageView_team2);
        team1_short_name = v.findViewById(R.id.team1_short_name);
        team2_short_name = v.findViewById(R.id.team2_short_name);


        Glide.with(this).load(team1_logo)
                .centerCrop()
                .placeholder(getResources().getDrawable(R.mipmap.icon_ic_appicon_round))
                .into(imageView_team1);

        Glide.with(this).load(team2_logo)
                .centerCrop()
                .placeholder(getResources().getDrawable(R.mipmap.icon_ic_appicon_round))
                .into(imageView_team2);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && view != null) {
            onResume();
        }
    }

    private class AsyncTaskDetailMatch extends AsyncTask<String, String, String> {

        private String resp;
        //ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            Utillity.p(TAGC + " ", " AsyncTaskDetailMatch ---");
            Utillity.p(TAGC + " ", " API calling" + Constants.SCOREBOARDS_API.replace("{ID}", match_key));

            OkHttpClient client = new OkHttpClient();
            String urlString = Constants.SCOREBOARDS_API.replace("{ID}", match_key);
            Request request = new Request.Builder()
                    .url(urlString)
                    .get()
                    .build();

            try {
                Response response = client.newCall(request).execute();
                resp = response.body().string();

            } catch (Exception e) {
                e.printStackTrace();
                acProgressFlower.dismiss();
            }
//
//            OkHttpClient client = new OkHttpClient();
//            String urlString = Constants.MATCH_DETAIL_API.replace("matchKey",params[0]) + Constants.getAccessToken(LiveLineActivity.this);
//            Request request = new Request.Builder()
//                    .url(urlString)
//                    .get()
//                    .build();
//
//            try {
//                Response response = client.newCall(request).execute();
//                resp = response.body().string();
//
//            } catch (Exception e) {
//                e.printStackTrace();
//                acProgressFlower.dismiss();
//            }
            return resp;
        }


        @Override
        protected void onPostExecute(String res) {
            // execution of result of Long time consuming operation
            // progressDialog.dismiss();
            ///    //System.out.println("ddddddddd"+res);

            try {
                final JSONObject response = new JSONObject(res);

                Utillity.p(TAGC + " ", " onPostExecuteresponse =" + response);

                acProgressFlower.dismiss();

                try {
                    team1_short_name.setText(team1_name);
                    team2_short_name.setText(team2_name);

                    if (!score.equals("")) {
                        team1_runs.setText(score);
                    }
                    if (!score2.equals("")) {
                        team2_runs.setText(score2);
                    }

                    if (!team1_oversstr.equals("") & !team1_oversstr.equals("0")) {
                        team1_overs.setText(team1_oversstr);
                    }
                    if (!team2_oversstr.equals("") & !team2_oversstr.equals("0")) {
                        team2_overs.setText(team2_oversstr);
                    }

                    remain_balls.setText(response.getInt("remainingballs") + "");
                    need_run.setText(response.getInt("needrun") + "");

                    // Required Run Rate = (Runs required to win / Balls Remaining ) x 6
                    run_rate.setText("" + (response.getInt("target") / response.getInt("remainingballs") * 6));


                    //If a team has scored 227 runs and has faced 5 overs in that time, then:
                    //Run Rate (runs per over) = 227 / 5
                    //Run Rate (runs per over) = 45.4

                    current_run_rate.setText("");

                    acProgressFlower.dismiss();

                } catch (Exception e) {
                    e.printStackTrace();
                    acProgressFlower.dismiss();
                }
            } catch (Exception e) {
                acProgressFlower.dismiss();
            }
        }

        @Override
        protected void onPreExecute() {
            acProgressFlower = new ACProgressFlower.Builder(getActivity())
                    .direction(ACProgressConstant.DIRECT_CLOCKWISE)
                    .themeColor(Color.WHITE)
                    .text("Please Wait")
                    .fadeColor(Color.DKGRAY).build();
            acProgressFlower.show();
            // progressDialog = ProgressDialog.show(getActivity(),"","");
        }


        @Override
        protected void onProgressUpdate(String... text) {
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!getUserVisibleHint()) {
            return;
        }
        Intent resultsIntent = new Intent("heightViewpagerInfo");
        resultsIntent.putExtra("height_s", "960");
        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(getActivity());

        localBroadcastManager.sendBroadcast(resultsIntent);
        if (CommonMethod.isNetworkAvailable(getActivity())) {
//            new AsyncTaskDetailMatch().execute(this.match_key);
            //    new NewLiveMatchDetail().execute(this.match_key);
            fetchMatchInfo();
        } else {
            CommonMethod.showAlert("Internet Connectivity Failure", getActivity());
        }


        if (CommonMethod.isNetworkAvailable(getActivity())) {
            new AsyncTaskDetailMatch().execute(this.match_key);
        } else {
            CommonMethod.showAlert("Internet Connectivity Failure", getActivity());
        }

    }

    private void fetchMatchInfo() {

        String url = Constants.MATCH_DETAIL_API + match_key + "/?access_token=" + Constants.getAccessToken(getContext());
        Log.d("URL_MAIN", url);
        StringRequest stringDRequest = new StringRequest(
                com.android.volley.Request.Method.GET,
                url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject jsonobject = new JSONObject(response);

                            JSONObject objDetails = jsonobject.getJSONObject("data");
                            JSONObject obj = objDetails.getJSONObject("card");

                            JSONObject team = obj.getJSONObject("teams");
                            Log.d("DEBUG_HOME", team.getJSONObject("a").getString("name"));
                            JSONObject team_1_json = team.getJSONObject("a");
                            JSONObject team_2_json = team.getJSONObject("b");
                            String series_n = obj.getString("title");
                            String location = obj.getString("venue");

                            String match_details = obj.getString("description");
                            String title = obj.getString("name");
                            String matchTyepe = obj.getString("format");
                            String date_time = obj.getJSONObject("start_date").getString("iso");
                            String match_s = obj.getString("status");
                            String team1_name = team_1_json.getString("name");
                            String team2_name = team_2_json.getString("name");
                            Log.d("DEBUG_HOME", team1_name + " V/S " + team2_name);

                            String flag1 = Constants.BANNER_IMAGE_URI + team_1_json.getString("key") + ".png";
                            String flag2 = Constants.BANNER_IMAGE_URI + team_2_json.getString("key") + ".png";

                            JSONObject details = obj.getJSONObject("innings");

                            String wicket, team1_runs, team1_overs;
                            String wicket2, team2_runs, team2_overs;

                            if (obj.getString("status").equals("completed")) {
                                if (details.has("a_1")) {
                                    JSONObject teamOneDetails = details.getJSONObject("a_1");
                                    wicket = teamOneDetails.getString("wickets");
                                    team1_runs = teamOneDetails.getString("runs");
                                    team1_overs = teamOneDetails.getString("overs");

                                } else {
                                    wicket = "0";
                                    team1_runs = "00";
                                    team1_overs = "00";

                                }

                                if (details.has("b_1")) {
                                    JSONObject teamTwoDetails = details.getJSONObject("b_1");
                                    wicket2 = teamTwoDetails.getString("wickets");
                                    team2_runs = teamTwoDetails.getString("runs");
                                    team2_overs = teamTwoDetails.getString("overs");
                                } else {
                                    wicket2 = "0";
                                    team2_runs = "00";
                                    team2_overs = "00";

                                }
                            } else {
                                wicket = "0";
                                team1_runs = "00";
                                team1_overs = "00";
                                wicket2 = "0";
                                team2_runs = "00";
                                team2_overs = "00";
                            }

                            String key = String.valueOf(match_key);
                            if (batlist != null & batlist.size() > 0) {
                                batlist.clear();
                                balllist.clear();
                                runModelArrayList.clear();
                            }
                            //-----------------GETTING DATA FROM LIVE FRAGMENT--------------------------
                            JSONObject liveObject = obj.getJSONObject("now");
                            String strikerKey = liveObject.getJSONObject("last_ball").getString("striker");
                            String nonStrikerKey = liveObject.getJSONObject("last_ball").getString("nonstriker");

                            JSONObject teamPlayersInfo = obj.getJSONObject("players");

                            JSONObject batsManDetails = teamPlayersInfo.getJSONObject(strikerKey).getJSONObject("match").getJSONObject("innings").getJSONObject("1").getJSONObject("batting");
                            String Strikername = teamPlayersInfo.getJSONObject(strikerKey).getString("fullname");
                            if (batsManDetails.has("runs")) {
                                String run = batsManDetails.getString("runs");
                                String s4 = batsManDetails.getString("fours");
                                String s6 = batsManDetails.getString("sixes");
                                String sr = batsManDetails.getString("strike_rate");
                                String balls = batsManDetails.getString("balls");
                                batlist.add(
                                        new BattingItem(
                                                Strikername + "",
                                                run + "",
                                                s4 + "",
                                                s6 + "",
                                                sr + "",
                                                balls + "")
                                );
                                LinearLayoutManager manager = new LinearLayoutManager(getActivity());
                                bat_list.setLayoutManager(manager);
                                bat_list.setHasFixedSize(true);
                                BattingAdapter bat_Ada = new BattingAdapter(batlist, getActivity());
                                bat_list.setAdapter(bat_Ada);
                            }

                            JSONObject batsNManDetails = teamPlayersInfo.getJSONObject(nonStrikerKey).getJSONObject("match").getJSONObject("innings").getJSONObject("1").getJSONObject("batting");
                            String nonStrikername = teamPlayersInfo.getJSONObject(nonStrikerKey).getString("fullname");
                            if (batsManDetails.has("runs")) {
                                String run = batsNManDetails.getString("runs");
                                String s4 = batsNManDetails.getString("fours");
                                String s6 = batsNManDetails.getString("sixes");
                                String sr = batsNManDetails.getString("strike_rate");
                                String balls = batsNManDetails.getString("balls");
                                batlist.add(
                                        new BattingItem(
                                                nonStrikername + "",
                                                run + "",
                                                s4 + "",
                                                s6 + "",
                                                sr + "",
                                                balls + "")
                                );
                                LinearLayoutManager manager = new LinearLayoutManager(getActivity());
                                bat_list.setLayoutManager(manager);
                                bat_list.setHasFixedSize(true);
                                BattingAdapter bat_Ada = new BattingAdapter(batlist, getActivity());
                                bat_list.setAdapter(bat_Ada);
                            }

                            String bowlerKey = liveObject.getJSONObject("last_ball").getJSONObject("bowler").getString("key");
                            JSONObject bowlerDetails = teamPlayersInfo.getJSONObject(bowlerKey).getJSONObject("match").getJSONObject("innings").getJSONObject("1").getJSONObject("bowling");
                            String nameB = teamPlayersInfo.getJSONObject(bowlerKey).getString("fullname");

                            if (bowlerDetails.has("overs")) {
                                String over = bowlerDetails.getString("overs");
                                String run = bowlerDetails.getString("runs");
                                String wic = bowlerDetails.getString("wickets");
                                String eco = bowlerDetails.getString("economy");
                                String m = bowlerDetails.getString("maiden_overs");
                                balllist.add(
                                        new BowlerItems(
                                                nameB + "",
                                                over + "",
                                                run + "",
                                                wic + "",
                                                eco + "",
                                                m + ""
                                        )
                                );
                                LinearLayoutManager ball_manager = new LinearLayoutManager(getActivity());
                                ball_list.setLayoutManager(ball_manager);
                                ball_list.setHasFixedSize(true);
                                BowlingAdapter ball_Ada = new BowlingAdapter(balllist, getActivity());
                                ball_list.setAdapter(ball_Ada);
                            }

                            JSONObject ballsDetails = obj.getJSONObject("balls");
                            Iterator iteratorObj = ballsDetails.keys();
                            while (iteratorObj.hasNext()) {
                                final JSONObject objc;
                                String getJsonObj = (String) iteratorObj.next();
                                objc = ballsDetails.getJSONObject(getJsonObj);

                                RunModel runModel = new RunModel();
                                String over = String.valueOf(objc.getInt("over"));
                                String ball = String.valueOf(Integer.valueOf(objc.getString("ball")));
                                String run = objc.getString("wicket").equals("") ? String.valueOf(objc.getJSONObject("batsman").getInt("runs")) : "w";
                                runModel.setOver(over);
                                runModel.setBall(ball);
                                runModel.setRun(run);
                                runModelArrayList.add(runModel);
                            }

                            Collections.sort(runModelArrayList, new Comparator<RunModel>() {
                                @Override
                                public int compare(RunModel lhs, RunModel rhs) {
                                    return String.valueOf(lhs.getOver()).compareTo(String.valueOf(rhs.getOver()));
                                }
                            });
                            for (int i = 0; i < 6; i++) {
                                Toast.makeText(getContext(), String.valueOf(runModelArrayList.get(i).getRun()), Toast.LENGTH_LONG).show();
                                if (i == 0) {
                                    if (runModelArrayList.get(i).getRun().toString().equalsIgnoreCase("w")) {
                                       // ball1_im.setImageResource(R.drawable.wkt_ball);
                                        ball1_tv.setText("wkt");
                                    } else {
                                        ball1_tv.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));
                                        ball1_im.setImageResource(R.drawable.runs);
                                    }
                                    ball1_tv.setVisibility(View.VISIBLE);

                                }
                                if (i == 1) {
                                    if (runModelArrayList.get(i).getRun().toString().equalsIgnoreCase("w")) {
                                      //  ball2_im.setImageResource(R.drawable.wkt_ball);
                                        ball2_tv.setText("wkt");
                                    } else {
                                        ball2_tv.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));
                                        ball2_im.setImageResource(R.drawable.runs);
                                    }
                                    ball2_tv.setVisibility(View.VISIBLE);

                                }
                                if (i == 2) {
                                    if (runModelArrayList.get(i).getRun().toString().equalsIgnoreCase("w")) {
                                       // ball3_im.setImageResource(R.drawable.wkt_ball);
                                        ball3_tv.setText("wkt");
                                    } else {
                                        ball3_tv.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));
                                        ball3_im.setImageResource(R.drawable.runs);
                                    }
                                    ball3_tv.setVisibility(View.VISIBLE);

                                }
                                if (i == 3) {
                                    if (runModelArrayList.get(i).getRun().toString().equalsIgnoreCase("w")) {
                                       // ball4_im.setImageResource(R.drawable.wkt_ball);
                                        ball4_tv.setText("wkt");
                                    } else {
                                        ball4_tv.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));
                                        ball4_im.setImageResource(R.drawable.runs);
                                    }
                                    ball4_tv.setVisibility(View.VISIBLE);

                                }
                                if (i == 4) {
                                    if (runModelArrayList.get(i).getRun().toString().equalsIgnoreCase("w")) {
                                        //ball5_im.setImageResource(R.drawable.wkt_ball);
                                        ball5_tv.setText("wkt");
                                    } else {
                                        ball5_tv.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));
                                        ball5_im.setImageResource(R.drawable.runs);
                                    }
                                    ball5_tv.setVisibility(View.VISIBLE);

                                }
                                if (i == 5) {
                                    if (runModelArrayList.get(i).getRun().toString().equalsIgnoreCase("w")) {
                                       // ball6_im.setImageResource(R.drawable.wkt_ball);
                                        ball6_tv.setText("wkt");
                                        last_run.setText("W");

                                    } else {
                                        ball6_tv.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));
                                        ball6_im.setImageResource(R.drawable.runs);
                                        last_run.setText("" + String.valueOf(runModelArrayList.get(i).getRun()));

                                    }
                                    ball6_tv.setVisibility(View.VISIBLE);

                                }
                            }
                            acProgressFlower.dismiss();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Log.d("DEBUG_ERROR", e.getMessage());

                        }

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("DEBUG_ERROR", error.getMessage());
                    }
                }
        );
        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);
    }


}