package farm.liveline.BossScore.activities;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import farm.liveline.BossScore.R;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //-------RUNNING INTENT FOR FLASH SCREEN FOR 1 SEC WITH THREAD-------------------------
        final Intent i=new Intent(this, MainActivity.class);
        Thread timmer=new Thread(){
            @Override
            public void run() {
                try {
                    sleep(1000);
                    startActivity(i);
                    finish();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        timmer.start();
        //----------------------CLOSE----------------------------
    }
}
