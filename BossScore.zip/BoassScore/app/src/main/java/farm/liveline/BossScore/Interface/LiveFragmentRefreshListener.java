package farm.liveline.BossScore.Interface;

import org.json.JSONObject;

public interface LiveFragmentRefreshListener
{
    void onRefresh(JSONObject jsonObject);
}
