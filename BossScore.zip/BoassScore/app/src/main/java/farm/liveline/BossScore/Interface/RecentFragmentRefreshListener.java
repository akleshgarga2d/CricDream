package farm.liveline.BossScore.Interface;

import org.json.JSONObject;

public interface RecentFragmentRefreshListener
{
    void onRefresh(JSONObject jsonObject);
}
