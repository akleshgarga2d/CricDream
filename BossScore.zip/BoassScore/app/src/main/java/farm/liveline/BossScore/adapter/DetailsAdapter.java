package farm.liveline.BossScore.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import farm.liveline.BossScore.R;
import farm.liveline.BossScore.beans.DetailsItems;

public class DetailsAdapter extends BaseAdapter {

    private Activity activity;
    private LayoutInflater inflater;
    private List<DetailsItems> listItems;

    public DetailsAdapter(Activity activity, List<DetailsItems> listItems) {
        this.activity = activity;
        this.listItems = listItems;
    }

    @Override
    public int getCount() {

        return listItems.size();
    }

    @Override
    public Object getItem(int position) {
        return listItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.match_details_layout, null);

        TextView series_name = (TextView) convertView.findViewById(R.id.details_tour_name);
        TextView team_one = (TextView) convertView.findViewById(R.id.team_one_name_details);
        TextView team_two = (TextView) convertView.findViewById(R.id.team_two_name_details);
        TextView details_info = (TextView) convertView.findViewById(R.id.details_info);
        TextView details_info_more = (TextView) convertView.findViewById(R.id.details_venue);
        CircleImageView flag_one = (CircleImageView) convertView.findViewById(R.id.flag_one_details);
        CircleImageView flag_two = (CircleImageView) convertView.findViewById(R.id.flag_two_details);
        TextView time = (TextView) convertView.findViewById(R.id.time_info);


        // getting movie data for the row
        DetailsItems m = listItems.get(position);

        // thumbnail image

        // title
        series_name.setText(m.getTour_info());
        team_one.setText(m.getTeam_one());
        team_two.setText(m.getTeam_two());
        details_info.setText(m.getMore_info());
        details_info_more.setText(m.getVenue());
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

        Date sourceDate = null;
        try {
            sourceDate = inputFormat.parse(m.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat targetFormat = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        time.setText(targetFormat.format(sourceDate));

        //time.setText(m.getTime());

        try {
            if (!m.getFlag_one().equals("ER")) {
                Glide.with(activity.getApplicationContext())
                        .load(m.getFlag_one())
                        .placeholder(R.mipmap.icon_ic_appicon_round)
                        .into(flag_one);
            } else {
                Glide.with(activity.getApplicationContext())
                        .load(R.mipmap.icon_ic_appicon_round)
                        .into(flag_one);
            }

            if (!m.getFlag_two().equals("ER")) {
                Glide.with(activity.getApplicationContext())
                        .load(m.getFlag_two())
                        .placeholder(R.mipmap.icon_ic_appicon_round)
                        .into(flag_two);
            } else {
                Glide.with(activity.getApplicationContext())
                        .load(R.mipmap.icon_ic_appicon_round)
                        .into(flag_two);
            }

        } catch (Exception e) {

        }
       /* Glide.with(activity.getApplicationContext())
                .load(m.getFlag_one())
                .into(flag_one);
        Glide.with(activity.getApplicationContext())
                .load(m.getFlag_two())
                .into(flag_two);*/
        return convertView;
    }
}
