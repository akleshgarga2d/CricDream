package farm.liveline.BossScore.beans;

public class PointTableItem {
    String team_name;
    String w;
    String l;

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getW() {
        return w;
    }

    public void setW(String w) {
        this.w = w;
    }

    public String getL() {
        return l;
    }

    public void setL(String l) {
        this.l = l;
    }

    public String getD() {
        return d;
    }

    public void setD(String d) {
        this.d = d;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public String getP() {
        return p;
    }

    public void setP(String p) {
        this.p = p;
    }
    public PointTableItem() {
    }
    public PointTableItem(String team_name, String w, String l, String d, String m, String p) {
        this.team_name = team_name;
        this.w = w;
        this.l = l;
        this.d = d;
        this.m = m;
        this.p = p;
    }

    String d;
    String m;
    String p;
}
