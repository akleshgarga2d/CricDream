package farm.liveline.BossScore.fragments.matches_fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.List;

import farm.liveline.BossScore.R;
import farm.liveline.BossScore.adapter.DetailsAdapter;
import farm.liveline.BossScore.beans.DetailsItems;

public class MatchesFragment extends Fragment {
    private ListView mListView;
    private DetailsAdapter mAdapter;
    private List<DetailsItems> mItemList = new ArrayList<>();
    private ProgressBar mProgressBar;
    final static String url = "https://cricket-exchange.firebaseio.com/liveMatches.json";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_matches, container, false);
        mListView = view.findViewById(R.id.matches_list);
        mProgressBar = view.findViewById(R.id.loading_matches);
        mAdapter = new DetailsAdapter(getActivity(), mItemList);
        mListView.setAdapter(mAdapter);
        mFetchListFromAPI();

        return view;
    }

    private void mFetchListFromAPI() {
        int i = 0;
        while (i < 10) {
            DetailsItems matchDetails = new DetailsItems();
            matchDetails.setTour_info("India Tour of South africa");
            matchDetails.setMore_info("IND vs SA ,1st ODI,1-st");
            matchDetails.setVenue("Ranjhi, Jabalpur");
            matchDetails.setFlag_one("https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/255px-Flag_of_India.svg.png");
            matchDetails.setFlag_two("https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Flag_of_South_Africa.svg/255px-Flag_of_South_Africa.svg.png");
            matchDetails.setTeam_one("India");
            matchDetails.setTeam_two("South Africa");
            mItemList.add(matchDetails);
            i++;

        }
        mListView.setVisibility(View.VISIBLE);
        mProgressBar.setVisibility(View.INVISIBLE);
        mAdapter.notifyDataSetChanged();
/*
        StringRequest stringDRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //    mProgressBar.setVisibility(View.GONE);

                        try {
                            mListView.setVisibility(View.VISIBLE);
                            mProgressBar.setVisibility(View.INVISIBLE);
                            JSONObject jsonobject = new JSONObject(response);
                            //  Toast.makeText(getApplicationContext(),jsonobject.get(),Toast.LENGTH_LONG).show();
                            Iterator iteratorObj = jsonobject .keys();

                            while (iteratorObj.hasNext())
                            {
                                final JSONObject obj;
                                String getJsonObj = (String)iteratorObj.next();
                                System.out.println("KEY: " + "------>" + getJsonObj);
                                DetailsItems matchDetails=new DetailsItems();
                                obj = jsonobject.getJSONObject(getJsonObj);
                                System.out.println("Value: " + "------>" + obj.getString("date").toString());

                                matchDetails.setTour_info(obj.getString("series_name").toString());
                                matchDetails.setMore_info(obj.getString("t1"));
                                matchDetails.setVenue(obj.getString("t2"));
                                matchDetails.setFlag_one(obj.getString("date"));
                                matchDetails.setFlag_two(obj.getString("t1"));
                                matchDetails.setTeam_one(obj.getString("t2"));
                                matchDetails.setTeam_two(obj.getString("date"));
                                mItemList.add(matchDetails);

                            }
                            mAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //   CreateRoomListFromDatabase(user_id);
                        mProgressBar.setVisibility(View.GONE);
                        Toast.makeText(getContext(), "API NOT WORKING !", Toast.LENGTH_SHORT).show();

                    }
                }
        );

        RequestHandler.getInstance(getActivity()).addToRequestQueue(stringDRequest);

 */
    }


}
