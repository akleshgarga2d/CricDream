package farm.liveline.BossScore.Interfaces;

public interface OnItemClickListner {
    public void onClick(int position);

}
